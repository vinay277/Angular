import { Pipe, PipeTransform } from '@angular/core'

@Pipe({ name: 'phonenumber' })

export class PhoneNumberPipe implements PipeTransform {
    transform(value): string {
        let pattern = /[^0-9]/g;
        if (pattern.test(value)){
            console.log(value.includes("a"))
        return "NA"
        }else{
        return value;
        }
    }
}