import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {HttpClient} from '@angular/common/http'
import { EmployeeService } from '../employee.service';
import { FormControl, FormGroup, FormBuilder } from "@angular/forms"
import { Validators } from "@angular/forms"

@Component({
  selector: 'pm-edit-employee',
  templateUrl: './edit-employee.component.html'
})
export class EditEmployeeComponent implements OnInit {
  employeeDetail
  employeeForm: FormGroup
  constructor(private route: ActivatedRoute, 
    private employee: EmployeeService,
     private formBuilder: FormBuilder,
    private router: Router) { }

  Validations() {
    this.employeeForm = this.formBuilder.group({
      name: ['', Validators.required],
      id: ['', Validators.required],
      phone: ['', Validators.required],
      address: this.formBuilder.group({
        street: ['', Validators.required],
        city: ['', Validators.required],
        state: ['', Validators.required],
        PostCode: ['', Validators.required]
      })
    })
  }

  saveEmployee(value, id) {
    console.log(id)
    this.employee.saveEmployeebyName(value, id)
    this.router.navigate(['/employee'])
  }

  cancel() {
    this.router.navigate(['/employee'])
  }
  ngOnInit() {
    this.Validations();
    this.employeeDetail = this.employee.getEmployeebyID(+this.route.snapshot.params['id'])
    console.log(this.employeeDetail)
  }


}
