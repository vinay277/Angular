import { Component, OnInit } from '@angular/core';
import { LoginService } from './login.service';
import { Router } from '@angular/router';
import { ValueTransformer } from '@angular/compiler/src/util';

@Component({
  selector: 'pm-login',
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit  {
  registerClicked:boolean = false
  userList
  constructor(private auth:LoginService, private router:Router){}

  ngOnInit(){
    console.log(loginForm.value);
  }
 
  login(value){
    let currentUser;
    if(!this.registerClicked){
    currentUser = this.auth.getUser(value.name)
    } else
    {
     currentUser = this.userList 
    }
    console.log(currentUser)
    if(currentUser){
    if (value.password == currentUser.password){
      this.router.navigate(['/employee'])
    }
    else{
      alert("Please enter the correct credentials")
    }
  } else{
    alert("You are not the valid user")
  }
  }

  register(form){
   
    this.registerClicked = true
    this.userList = this.auth.addUser(form.value)
    confirm(`user ${this.userList.name} has been successfully added to the registered users
            Please login with your valid credentials`)
    this.router.navigate(['/login'])  
    form.form.reset();
  }

}

