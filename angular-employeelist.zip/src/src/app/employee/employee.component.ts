import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { EmployeeService } from './employee.service';


@Component({
  selector: 'pm-employee',
  templateUrl: './employee.component.html'
})
export class EmployeeComponent implements OnInit {
  list
  employeeList
  filteredEmployee
  constructor(private employee: EmployeeService, private router:Router) { }
_listFilter:string;
get listFilter(){
  return this._listFilter;
}
set listFilter(value){
this._listFilter = value;
this.filteredEmployee = this.listFilter ? this.performFilter(this.listFilter) : this.employeeList
}

  performFilter(filterby) {
     filterby = filterby.toLocaleLowerCase();
    return this.employeeList.filter((employee) =>
      employee.name.toLocaleLowerCase().indexOf(filterby) !== -1);
  }

  addEmployee(){
    this.router.navigate(['/employee/add']);
  } 

  deleteEmployee(value){
    this.employee.DeleteEmployee(value)
  }

  ngOnInit() {
    this.employee.getEmployee().subscribe(data=>{
      this.list = data
      this.employeeList = this.list
      this.filteredEmployee = this.employeeList
    })
  }


}
