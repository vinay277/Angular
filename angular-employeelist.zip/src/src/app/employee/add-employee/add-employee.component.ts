import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from "@angular/forms"
import { Validators } from "@angular/forms"
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'pm-add-employee',
  templateUrl: './add-employee.component.html'
})
export class AddEmployeeComponent implements OnInit {
  employeeForm: FormGroup
  constructor(private formBuilder: FormBuilder, private employee:EmployeeService, private router:Router) { }

  Validations() {
    this.employeeForm = this.formBuilder.group({
      name: ['', Validators.required],
      id: ['', Validators.required],
      phone: ['', Validators.required],
      address: this.formBuilder.group({
          street: ['', Validators.required],
          city: ['', Validators.required],
          state: ['', Validators.required],
          PostCode: ['', Validators.required]
      })
    })
  }

  cancel() {
    this.router.navigate(['/employee'])
  }


  saveEmployee(value) {
    console.log(value)
    this.employee.saveEmployee(value)
    this.router.navigate(['/employee'])
  }
  
  ngOnInit() {
      this.Validations();
  }

}
