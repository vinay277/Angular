import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router';

import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeService } from './employee/employee.service';
import { EditEmployeeComponent } from './employee/edit-employee/edit-employee.component';
import { WelcomeComponent } from './home/welcome.component';
import { AddEmployeeComponent } from './employee/add-employee/add-employee.component';
import { PhoneNumberPipe } from './shared/phone-number.pipe';
import { LoginComponent } from './login/login.component';
import { LoginService } from './login/login.service';


@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    EditEmployeeComponent,
    WelcomeComponent,
    AddEmployeeComponent,
    PhoneNumberPipe,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
    {path:'login',component:LoginComponent},
    {path:'welcome',component:WelcomeComponent},
    {path:'employee',component:EmployeeComponent },
    { path: 'employee/add', component: AddEmployeeComponent },
    {path:'employee/:id',component:EditEmployeeComponent},
    {path:'',redirectTo:'login',pathMatch:'full'}
    ])
  ],
  providers: [EmployeeService, LoginService],
  bootstrap: [AppComponent]
})
export class AppModule { }
