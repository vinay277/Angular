import { Injectable } from "@angular/core";

@Injectable()

export class LoginService {

  getUser(name) {
    return USER.find(user => user.name === name)
  }

  addUser(user) {
    USER.push(user)
    return USER
  }
}

const USER = [
  {
    "name": "vinay",
    "password": "password1"
  },
  {
    "name": "himanshi",
    "password": "password2"
  },
  {
    "name": "vijay",
    "password": "password3"
  }
]

