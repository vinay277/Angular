import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/map';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class EmployeeService {
  url='../api/employee/employee.json'
  temp;
  filteredEmployee
  constructor(private http: HttpClient) { }

  getEmployee() {
    let subject = new Subject()
    setTimeout(() => { subject.next(EMPLOYEE); subject.complete(); }, 100)
    return subject
  }

  getEmployeebyID(id: number) {
  return EMPLOYEE.find(employee => employee.id === id)
  }

  saveEmployee(employee) {
    EMPLOYEE.push(employee)
  }

  saveEmployeebyName(employee, id) {
    // this.filteredEmployee=EMPLOYEE.find(employee => employee.id === id)
    // console.log(this.filteredEmployee)
    EMPLOYEE.push(employee)
    EMPLOYEE.pop();
  }

   DeleteEmployee(employee) {
    let temp =EMPLOYEE.indexOf(employee)
    EMPLOYEE.splice(temp,1)
  }

}

const EMPLOYEE = [
  {
    "id": 66896,
    "name": "Vinay",
    "phone": "9620529048",
    "address": {
      "city": "Bangalore",
      "street": "ABC street",
      "state": "Karnataka",
      "PostCode": "560076"
    }
  },
  {
    "id": 66923,
    "name": "John",
    "phone": "7720808609",
    "address": {
      "city": "Hyderabad",
      "street": "PQR street",
      "state": "Telangana",
      "PostCode": "412114"
    }
  },
  {
    "id": 66898,
    "name": "Vijay",
    "phone": "8888830456",
    "address": {
      "city": "Pune",
      "street": "Kothrud",
      "state": "Maharastra",
      "PostCode": "411067"
    }
  },
  {
    "id": 66945,
    "name": "Sneha",
    "phone": "75df426897",
    "address": {
      "city": "Pune",
      "street": "Buldana",
      "state": "Maharastra",
      "PostCode": "414098"
    }
  },
  {
    "id": 66898,
    "name": "Amit",
    "phone": "8848683056",
    "address": {
      "city": "Pune",
      "street": "Solapur",
      "state": "Maharastra",
      "PostCode": "413067"
    }
  }
]

